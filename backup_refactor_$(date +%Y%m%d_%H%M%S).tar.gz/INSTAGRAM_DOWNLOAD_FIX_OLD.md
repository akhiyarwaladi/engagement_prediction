# Instagram Download Fix - gallery-dl dengan Cookies

**Date:** October 4, 2025
**Status:** ✅ WORKING - 396 posts downloaded successfully

---

## 🚨 PROBLEM

Instagram API tidak lagi mendukung login dengan **username/password** di gallery-dl.

```bash
# ❌ TIDAK BEKERJA (401 Unauthorized)
gallery-dl --config config.json https://www.instagram.com/fst_unja/
```

Error:
```
[instagram][error] HttpError: '401 Unauthorized' for 'https://www.instagram.com/api/v1/users/web_profile_info/?username=fst_unja'
```

---

## ✅ SOLUTION YANG BEKERJA

### Command Final (Tested October 4, 2025):

```bash
gallery-dl --cookies cookies.txt --write-metadata --filter "username == 'fst_unja'" https://www.instagram.com/fst_unja/
```

**Hasil:** 396 posts (photos + videos) + 396 JSON metadata files

---

## 🔑 PENJELASAN PARAMETER

| Parameter | Fungsi | Penting? |
|-----------|--------|----------|
| `--cookies cookies.txt` | Gunakan cookies dari file (authentication) | ✅ WAJIB |
| `--write-metadata` | Generate file JSON metadata per post | ✅ WAJIB |
| `--filter "username == 'fst_unja'"` | Hanya download dari @fst_unja, TIDAK ikut akun yang di-tag | ✅ SANGAT PENTING |
| `https://www.instagram.com/fst_unja/` | URL target account | ✅ WAJIB |

---

## 📥 CARA MEMBUAT cookies.txt

**Method 1: Export Manual dari Browser (RECOMMENDED)**

1. **Login ke Instagram** di browser (Chrome/Edge)
   - URL: https://www.instagram.com
   - Akun: `akhiyarwaladi` (atau akun apapun yang sudah login)

2. **Tekan F12** → Tab **Application**

3. **Klik Cookies** → `https://www.instagram.com`

4. **Copy nilai cookies:**
   - `sessionid` (PALING PENTING!)
   - `csrftoken`
   - `ds_user_id`

5. **Buat file `cookies.txt`** dengan format Netscape:

```
# Netscape HTTP Cookie File
.instagram.com	TRUE	/	TRUE	0	sessionid	PASTE_SESSIONID_DISINI
.instagram.com	TRUE	/	TRUE	0	csrftoken	PASTE_CSRFTOKEN_DISINI
.instagram.com	TRUE	/	TRUE	0	ds_user_id	PASTE_DS_USER_ID_DISINI
```

**CATATAN:** Gunakan TAB (bukan spasi) sebagai separator!

6. **Save** sebagai `cookies.txt` di folder project

---

## SOLUTION OPTIONS

### Option 1: Close Chrome and Use Cookies (RECOMMENDED)

**Steps:**
1. Close ALL Chrome windows completely
2. Run this command:
```bash
gallery-dl --cookies-from-browser chrome https://www.instagram.com/fst_unja/
```

**Why this works:** Chrome locks the cookies database while running

---

### Option 2: Export Cookies Manually (EASIEST)

**Steps:**
1. Install Chrome extension: "Get cookies.txt LOCALLY"
   - URL: https://chrome.google.com/webstore/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc

2. Open instagram.com in Chrome and login

3. Click extension icon → Export cookies.txt

4. Save as: `C:\Users\MyPC PRO\Documents\engagement_prediction\instagram_cookies.txt`

5. Run gallery-dl with cookies file:
```bash
gallery-dl --cookies instagram_cookies.txt https://www.instagram.com/fst_unja/
```

---

### Option 3: Use Instaloader with Session File (ALTERNATIVE)

If gallery-dl continues to fail, use instaloader:

**Steps:**
1. Login and save session:
```bash
instaloader --login=akhiyarwaladi --sessionfile=session-akhiyarwaladi
```

2. Download posts:
```bash
instaloader --sessionfile=session-akhiyarwaladi profile fst_unja
```

3. Extract metadata with existing script

---

### Option 4: Manual Cookie Export (TECHNICAL)

**Steps:**
1. Open Chrome DevTools (F12)
2. Go to instagram.com (logged in)
3. Network tab → Select any request
4. Right-click → Copy → Copy as cURL
5. Extract cookies from cURL command
6. Create cookies.txt in Netscape format:

```
# Netscape HTTP Cookie File
.instagram.com	TRUE	/	TRUE	0	sessionid	YOUR_SESSIONID_HERE
.instagram.com	TRUE	/	TRUE	0	csrftoken	YOUR_CSRF_HERE
```

7. Run:
```bash
gallery-dl --cookies cookies.txt https://www.instagram.com/fst_unja/
```

---

## CURRENT STATUS

**Existing Data:**
- Gallery-dl directory exists: `gallery-dl/instagram/fst_unja/`
- Already downloaded: 10 files (9 images + 1 video, 34MB)
- Metadata CSV exists: `fst_unja_from_gallery_dl.csv` (271 posts metadata)

**What We Have:**
✅ Post metadata (captions, dates, likes) - 271 posts
✅ BERT text embeddings - already extracted
✅ ViT visual embeddings - already extracted
✅ Trained models (Phase 0-5.1)

**What's Missing:**
❌ Raw image/video files for most posts (261 files missing)

**Impact:**
- Can continue experiments with existing embeddings (already cached)
- Cannot re-extract ViT embeddings from scratch without raw files
- BERT embeddings don't need files (text-only)

---

## QUICK FIX SCRIPT

Created: `scripts/download_with_session.py`

Run with:
```bash
python scripts/download_with_session.py
```

This will attempt multiple methods automatically.

---

## WHY GALLERY-DL WORKED BEFORE

Gallery-dl likely worked before because:
1. Instagram didn't require authentication for public profiles
2. OR Chrome was closed when running gallery-dl
3. OR An existing cookie file was present

**Instagram changed their API** around mid-2024 to require authentication even for public profiles.

---

## RECOMMENDED ACTION NOW

**Immediate (5 minutes):**
1. Close Chrome completely
2. Run: `gallery-dl --cookies-from-browser chrome https://www.instagram.com/fst_unja/`

**If that fails (10 minutes):**
1. Install "Get cookies.txt LOCALLY" Chrome extension
2. Export instagram.com cookies
3. Run with: `gallery-dl --cookies instagram_cookies.txt https://www.instagram.com/fst_unja/`

**If still fails (15 minutes):**
1. Use instaloader with session file (see Option 3)

---

## NOTES FOR CONTINUATION

**Current work focus:** Fix Instagram download with gallery-dl

**User requirements:**
- Wants to use gallery-dl specifically
- Mentioned it worked before
- Wants raw images/videos downloaded

**Existing scripts:**
- `extract_from_gallery_dl.py` - Metadata extraction (WORKING)
- `config.json` - Gallery-dl config (WORKING)
- `scripts/download_instagram.py` - Instaloader-based (ALTERNATIVE)
- `scripts/download_fresh_data.py` - Gallery-dl-based (NEEDS COOKIES)
- `scripts/download_with_session.py` - Multi-method (NEW)

**Next step after download succeeds:**
1. Run `python extract_from_gallery_dl.py` to extract metadata
2. Compare with existing CSV
3. Continue with experiments

---

**Generated:** 2025-10-04
**Status:** Awaiting user action (close Chrome OR export cookies)
