#!/usr/bin/env python3
"""
Download fresh Instagram data from @fst_unja
Uses gallery-dl for scraping
"""

import subprocess
import json
import pandas as pd
from pathlib import Path
from datetime import datetime
import argparse


def check_gallery_dl():
    """Check if gallery-dl is installed"""
    try:
        result = subprocess.run(['gallery-dl', '--version'], capture_output=True, text=True)
        print(f"[OK] gallery-dl version: {result.stdout.strip()}")
        return True
    except FileNotFoundError:
        print("[ERROR] gallery-dl not installed!")
        print("Install with: pip install gallery-dl")
        return False


def download_instagram_data(username='fst_unja', output_dir='gallery-dl', max_posts=500):
    """Download Instagram posts using gallery-dl"""

    print(f"\n[DOWNLOAD] Fetching Instagram data from @{username}")
    print(f"  Max posts: {max_posts}")
    print(f"  Output: {output_dir}/")

    # Create config
    config = {
        "extractor": {
            "instagram": {
                "cookies-from-browser": "chrome",
                "videos": True,
                "video-url": True,
                "include": "posts",
                "sleep-request": 2.0,
                "post-metadata-thumbnails": 2
            }
        }
    }

    config_path = Path('config_temp.json')
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    # Download command
    url = f"https://www.instagram.com/{username}/"

    cmd = [
        'gallery-dl',
        '--config', str(config_path),
        '--dest', output_dir,
        '--range', f'1-{max_posts}',
        url
    ]

    print(f"\n[CMD] {' '.join(cmd)}\n")

    try:
        result = subprocess.run(cmd, check=True, capture_output=False, text=True)
        print(f"\n[SUCCESS] Downloaded to {output_dir}/")
        config_path.unlink()
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Download failed: {e}")
        config_path.unlink()
        return False


def extract_to_csv(gallery_dir='gallery-dl/instagram/fst_unja', output_csv='fst_unja_fresh.csv'):
    """Extract JSON metadata to CSV"""

    print(f"\n[EXTRACT] Converting JSON to CSV...")

    gallery_path = Path(gallery_dir)
    if not gallery_path.exists():
        print(f"[ERROR] Directory not found: {gallery_dir}")
        return None

    # Find all JSON files
    json_files = list(gallery_path.glob('*.json'))
    print(f"  Found {len(json_files)} JSON files")

    if len(json_files) == 0:
        print("[WARNING] No JSON files found!")
        return None

    # Parse all posts
    posts = []

    for json_file in json_files:
        try:
            with open(json_file) as f:
                data = json.load(f)

            # Extract relevant fields
            post = {
                'post_id': data.get('id'),
                'shortcode': data.get('shortcode'),
                'url': f"https://www.instagram.com/p/{data.get('shortcode')}/",
                'username': data.get('owner', {}).get('username', 'fst_unja'),
                'date': data.get('date'),
                'caption': data.get('description', ''),
                'likes': data.get('edge_media_preview_like', {}).get('count', 0),
                'comments': data.get('edge_media_to_comment', {}).get('count', 0),
                'is_video': data.get('is_video', False),
                'video_views': data.get('video_view_count', 0) if data.get('is_video') else 0,
                'location': data.get('location', {}).get('name', '') if data.get('location') else '',
                'hashtags': ' '.join([f"#{tag}" for tag in data.get('tags', [])]),
                'hashtags_count': len(data.get('tags', [])),
                'mentions': ' '.join(data.get('mentions', [])),
                'mentions_count': len(data.get('mentions', [])),
                'media_type': 'video' if data.get('is_video') else 'photo',
                'width': data.get('dimensions', {}).get('width', 0),
                'height': data.get('dimensions', {}).get('height', 0),
                'file_path': str(json_file.with_suffix('.jpg' if not data.get('is_video') else '.mp4'))
            }

            posts.append(post)

        except Exception as e:
            print(f"  Error parsing {json_file.name}: {e}")

    # Create DataFrame
    df = pd.DataFrame(posts)
    df = df.sort_values('date', ascending=False).reset_index(drop=True)

    # Save
    df.to_csv(output_csv, index=False)
    print(f"  Saved {len(df)} posts to {output_csv}")

    # Summary
    print(f"\n[SUMMARY]")
    print(f"  Total posts: {len(df)}")
    print(f"  Photos: {(~df['is_video']).sum()}")
    print(f"  Videos: {df['is_video'].sum()}")
    print(f"  Date range: {df['date'].min()} to {df['date'].max()}")
    print(f"  Total likes: {df['likes'].sum()}")
    print(f"  Avg likes: {df['likes'].mean():.1f}")

    return df


def merge_with_existing(new_csv='fst_unja_fresh.csv',
                        existing_csv='fst_unja_from_gallery_dl.csv',
                        output_csv='fst_unja_merged.csv'):
    """Merge new data with existing data"""

    print(f"\n[MERGE] Combining datasets...")

    # Load
    new_df = pd.read_csv(new_csv)
    existing_df = pd.read_csv(existing_csv)

    print(f"  New data: {len(new_df)} posts")
    print(f"  Existing data: {len(existing_df)} posts")

    # Merge on post_id (keep most recent data)
    merged_df = pd.concat([new_df, existing_df]).drop_duplicates(
        subset=['post_id'], keep='first'
    ).sort_values('date', ascending=False).reset_index(drop=True)

    # Save
    merged_df.to_csv(output_csv, index=False)

    print(f"  Merged: {len(merged_df)} unique posts")
    print(f"  Saved to {output_csv}")

    return merged_df


def main():
    """Main execution"""

    parser = argparse.ArgumentParser(description='Download fresh Instagram data')
    parser.add_argument('--username', default='fst_unja', help='Instagram username')
    parser.add_argument('--max-posts', type=int, default=500, help='Maximum posts to download')
    parser.add_argument('--skip-download', action='store_true', help='Skip download, only extract')
    parser.add_argument('--output-dir', default='gallery-dl', help='Output directory')

    args = parser.parse_args()

    print("=" * 80)
    print("INSTAGRAM DATA DOWNLOADER")
    print("=" * 80)

    # Check gallery-dl
    if not args.skip_download:
        if not check_gallery_dl():
            return

        # Download
        success = download_instagram_data(
            username=args.username,
            output_dir=args.output_dir,
            max_posts=args.max_posts
        )

        if not success:
            print("\n[FAILED] Download unsuccessful")
            return

    # Extract to CSV
    df = extract_to_csv(
        gallery_dir=f'{args.output_dir}/instagram/{args.username}',
        output_csv='fst_unja_fresh.csv'
    )

    if df is None:
        print("\n[FAILED] Extraction unsuccessful")
        return

    # Merge with existing
    if Path('fst_unja_from_gallery_dl.csv').exists():
        merge_with_existing(
            new_csv='fst_unja_fresh.csv',
            existing_csv='fst_unja_from_gallery_dl.csv',
            output_csv='fst_unja_merged.csv'
        )

    print("\n" + "=" * 80)
    print("DOWNLOAD COMPLETE!")
    print("=" * 80)


if __name__ == "__main__":
    main()
