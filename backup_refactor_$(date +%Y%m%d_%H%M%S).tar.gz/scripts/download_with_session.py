#!/usr/bin/env python3
"""
Download Instagram posts using gallery-dl with session cookies
This script helps bypass the authentication requirement
"""

import subprocess
import sys
from pathlib import Path

def download_instagram(username='fst_unja', use_cookies=True):
    """Download Instagram posts using gallery-dl"""

    print("="*70)
    print("INSTAGRAM DOWNLOADER (gallery-dl)")
    print("="*70)

    # Build command
    cmd = ['gallery-dl', '--config', 'config.json']

    if use_cookies:
        # Try to use browser cookies
        # First try Chrome
        print("\nAttempting to use Chrome cookies...")
        cmd.extend(['--cookies-from-browser', 'chrome'])

    cmd.append(f'https://www.instagram.com/{username}/')

    print(f"\nCommand: {' '.join(cmd)}")
    print(f"\nDownloading from @{username}...")
    print("This may take a few minutes...\n")

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')

        print(result.stdout)

        if result.returncode != 0:
            print(f"\n[ERROR] Download failed with code {result.returncode}")
            print(result.stderr)

            # Try alternative: use existing session if available
            if use_cookies:
                print("\n[RETRY] Trying without cookies...")
                return download_instagram(username, use_cookies=False)
        else:
            print("\n[SUCCESS] Download completed!")

            # Run extraction script
            print("\n[EXTRACT] Running metadata extraction...")
            extract_cmd = [sys.executable, 'extract_from_gallery_dl.py']
            extract_result = subprocess.run(extract_cmd)

            if extract_result.returncode == 0:
                print("\n[SUCCESS] Metadata extracted to fst_unja_from_gallery_dl.csv")

        return result.returncode

    except Exception as e:
        print(f"\n[ERROR] Exception: {e}")
        return 1

def main():
    """Main execution"""

    # Check if gallery-dl is installed
    try:
        subprocess.run(['gallery-dl', '--version'], capture_output=True, check=True)
    except:
        print("[ERROR] gallery-dl not found. Install with: pip install gallery-dl")
        sys.exit(1)

    # Run download
    exit_code = download_instagram('fst_unja')

    sys.exit(exit_code)

if __name__ == "__main__":
    main()
