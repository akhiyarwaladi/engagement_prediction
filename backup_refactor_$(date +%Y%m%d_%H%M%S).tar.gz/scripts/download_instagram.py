#!/usr/bin/env python3
"""
Download Instagram data using instaloader
Requires: pip install instaloader
"""

import instaloader
import pandas as pd
from pathlib import Path
from datetime import datetime
import argparse


def download_profile_posts(username='fst_unja', max_posts=500, output_dir='gallery-dl'):
    """Download Instagram profile posts"""

    print(f"\n[INSTALOADER] Downloading @{username} posts...")
    print(f"  Max posts: {max_posts}")
    print(f"  Output: {output_dir}/")

    # Create instaloader instance
    L = instaloader.Instaloader(
        dirname_pattern=f'{output_dir}/instagram/{{target}}',
        download_videos=True,
        download_video_thumbnails=True,
        download_geotags=False,
        download_comments=False,
        save_metadata=True,
        compress_json=False,
        post_metadata_txt_pattern=''
    )

    # Try to load session (if exists)
    session_file = Path('instaloader_session')
    if session_file.exists():
        try:
            L.load_session_from_file(username, str(session_file))
            print("  Loaded saved session")
        except:
            print("  No saved session found, continuing without login")

    try:
        # Get profile
        profile = instaloader.Profile.from_username(L.context, username)

        print(f"\n[PROFILE] @{username}")
        print(f"  Posts: {profile.mediacount}")
        print(f"  Followers: {profile.followers}")
        print(f"  Following: {profile.followees}")

        # Download posts
        posts_data = []
        downloaded = 0

        for post in profile.get_posts():
            if downloaded >= max_posts:
                break

            try:
                # Download post
                L.download_post(post, target=username)

                # Extract metadata
                post_data = {
                    'post_id': post.mediaid,
                    'shortcode': post.shortcode,
                    'url': f'https://www.instagram.com/p/{post.shortcode}/',
                    'username': username,
                    'date': post.date_local,
                    'caption': post.caption if post.caption else '',
                    'likes': post.likes,
                    'comments': post.comments,
                    'is_video': post.is_video,
                    'video_views': post.video_view_count if post.is_video else 0,
                    'location': post.location.name if post.location else '',
                    'hashtags': ' '.join([f'#{tag}' for tag in post.caption_hashtags]),
                    'hashtags_count': len(post.caption_hashtags),
                    'mentions': ' '.join([f'@{m}' for m in post.caption_mentions]),
                    'mentions_count': len(post.caption_mentions),
                    'media_type': 'video' if post.is_video else 'photo',
                    'width': post.dimensions[0] if post.dimensions else 0,
                    'height': post.dimensions[1] if post.dimensions else 0,
                }

                posts_data.append(post_data)
                downloaded += 1

                if downloaded % 10 == 0:
                    print(f"  Downloaded {downloaded}/{max_posts} posts...")

            except Exception as e:
                print(f"  Error downloading post {post.shortcode}: {e}")
                continue

        # Create DataFrame
        df = pd.DataFrame(posts_data)

        # Save to CSV
        output_csv = f'{username}_fresh_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        df.to_csv(output_csv, index=False)

        print(f"\n[SUCCESS] Downloaded {len(df)} posts")
        print(f"  Saved to: {output_csv}")

        return df

    except instaloader.exceptions.ProfileNotExistsException:
        print(f"\n[ERROR] Profile @{username} does not exist!")
        return None
    except instaloader.exceptions.LoginRequiredException:
        print(f"\n[ERROR] Login required! Instagram requires authentication.")
        print("To login:")
        print("  1. Run: python -c 'import instaloader; L = instaloader.Instaloader(); L.login(\"YOUR_USERNAME\", \"YOUR_PASSWORD\"); L.save_session_to_file(\"instaloader_session\")'")
        print("  2. Re-run this script")
        return None
    except Exception as e:
        print(f"\n[ERROR] Download failed: {e}")
        return None


def main():
    """Main execution"""

    parser = argparse.ArgumentParser(description='Download Instagram data')
    parser.add_argument('--username', default='fst_unja', help='Instagram username')
    parser.add_argument('--max-posts', type=int, default=500, help='Maximum posts')
    parser.add_argument('--output-dir', default='gallery-dl', help='Output directory')

    args = parser.parse_args()

    print("=" * 80)
    print("INSTAGRAM DATA DOWNLOADER (Instaloader)")
    print("=" * 80)

    df = download_profile_posts(
        username=args.username,
        max_posts=args.max_posts,
        output_dir=args.output_dir
    )

    if df is not None:
        print("\n" + "=" * 80)
        print("DOWNLOAD COMPLETE!")
        print("=" * 80)
        print(f"\nDataset Summary:")
        print(f"  Total posts: {len(df)}")
        print(f"  Photos: {(~df['is_video']).sum()}")
        print(f"  Videos: {df['is_video'].sum()}")
        print(f"  Total likes: {df['likes'].sum()}")
        print(f"  Avg likes: {df['likes'].mean():.1f}")


if __name__ == "__main__":
    main()
